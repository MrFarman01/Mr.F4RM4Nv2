#!/data/data/com.termux/files/usr/bin/bash
#Jangan Recode Anjing
#Gua Susah Buatnya

#Bersihkan Kayar
clear
#Login Dulu Bossqw
cd Readme
python2 readme.py

#Warna
blue='\e[0;34'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'

#Backround HP
echo
    printf "\033[1;32m     ================= "
echo
    printf "\033[1;32m     ||___________°_||"
echo
    printf "\033[1;32m     ||             ||"
echo
    printf "\033[1;32m     || Mr.F4RM@!\! ||"
echo
    printf "\033[1;32m     ||             ||"
echo
    printf "\033[1;32m     || ----------- ||"
echo
    printf "\033[1;32m     || Tool V2.0.0 ||"
echo
    printf "\033[1;32m     || ----------- ||"
echo
    printf "\033[1;32m     ||             ||"
echo
    printf "\033[1;32m     ||      ::     ||"
echo
    printf "\033[1;32m     ||=============||"
echo
    printf "\033[1;32m     || []   {}   < ||"
echo
    printf "\033[1;32m     ================"



echo
#isinya Guys
figlet Mr.F4RM@N | lolcat
echo -e ""
echo -e $red"Tools By Mr.F4RM@!\!"
echo -e $white"Follow Me Instagram : @mr.f4rm4n  "
echo -e $red"My Site: http://www.twohidden.zone.id   "
echo -e $white"Contact Me In WhatsApp : +6285726308671  "
echo -e $red"Version : 2.0.0"
echo -e $white"Team:  Security Cyber Two   "
echo -e $red"Thank To All Member Two_Hidden   "
echo ""
echo -e $lightgreen" 01) Red Hawk"
echo -e $lightgreen" 02) WPScan"
echo -e $lightgreen" 03) Webdav"
echo -e $lightgreen" 04) Metasploit"
echo -e $lightgreen" 05) Youtube Dl"
echo -e $lightgreen" 06) viSQL"
echo -e $lightgreen" 07) Weeman"
echo -e $lightgreen" 08) FbBrute"
echo -e $lightgreen" 09) Ngrok"
echo -e $lightgreen" 10) Hammer "
echo -e $lightgreen" 11) xNot_Found "
echo -e $lightgreen" 12) Lazymux "
echo -e $lightgreen" 13) Hakku "
echo -e $lightgreen" 14) LulMrTirexV2 "
echo -e $lightgreen" 15) OSIF "
echo -e $lightgreen" 16) Lacak IP "
echo -e $lightgreen" 17) LiteDDOS "
echo -e $lightgreen" 18) B4J1N64Nv5 "
echo -e $lightgreen" 19) SQLMAP "
echo -e $lightgreen" 20) VIRUS MEMATIKAN "
echo -e $cayn" 00) Exit "
echo -e $white""
read -p "Pilih———> " act;

if [ $act = 1 ] || [ $act = 01 ]
then
clear
echo -e $red" Installing Red Hawk "
sleep 1
apt update && apt upgrade
apt install php
apt install git
git clone https://github.com/Tuhinshubhra/RED_HAWK
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 2 ] || [ $act = 02 ]
then
clear
echo -e $red" Installing Wpscan "
sleep 1
apt-get update && apt-get upgrade
apt install ruby
apt install curl
apt install git
git clone https://github.com/wpscanteam/wpscan
cd ~/wpscan
gem install Bundle 
bundle config build.nokogiri --use-system-libraries
bundle install
ruby wpscan.rb --update
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 3 ] || [ $act = 03 ]
then
clear
echo -e $red" Installing Webdav "
sleep 1
apt update && apt upgrade
apt install python2
pip2 install urllib3 chardet certifi idna requests
apt install openssl curl
pkg install libcurl
mkdir webdav
cd ~/webdav
wget https://pastebin.com/raw/HnVyQPtR -O webdav.py
chmod 777 webdav.py
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 04 ] || [ $act = 4 ]
then
clear
echo -e $red" Installing Metasploit "
sleep 1
apt update && apt upgrade
apt install git
apt install wget
wget https://raw.githubusercontent.com/verluchie/termux-metasploit/master/install.sh
chmod 777 install.sh
sh install.sh
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 05 ] || [ $act = 5 ]
then
clear
echo -e $red" Installing Youtube DL "
sleep 1
apt update && apt upgrade
apt install python
pip3 install mps_youtube
pip3 install youtube_dl
apt install mpv
echo " Untuk menjalankannya ketik "mpsyt" tanpa tanda petik "
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 06 ] || [ $act = 6 ]
then
clear
echo -e $red" Installing viSQL "
sleep 1
apt update && apt upgrade
pkg install git
pkg install python2
git clone https://github.com/blackvkng/viSQL.git
cd ~/viSQL
chmod 777 viSQL.py
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 07 ] || [ $act = 7 ]
then
clear
echo -e $red" Installing Weeman "
sleep 1
apt update && apt upgrade
pkg install git
apt install python2
git clone https://github.com/samyoyo/weeman
cd ~/weeman
pip2 install beautifulsoup
pip2 install bs4
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 08 ] || [ $act = 8 ]
then
clear
sleep 1
echo -e $red" Installing FBBrute "
apt install python2
apt install python2-dev
apt install wget
pip2 install mechanize
mkdir fbbrute
cd ~/fbbrute
wget https://pastebin.com/raw/aqMBt2xA -O fbbrute.py
chmod 777 fbbrute.py
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 09 ] || [ $act = 9 ]
then
clear
echo -e $red" Installing Ngrok "
sleep 1
apt install wget
mkdir ngrok
cd ~/ngrok
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
unzip ngrok-stable-linux-arm.zip
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 10 ] || [ $act = 10 ]
then
clear
echo -e $red" Installing Hammer "
sleep 1
pkg update
pkg upgrade
pkg install python
pkg install git
git clone https://github.com/cyweb/hammer
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 11 ] || [ $act = 11 ]
then
clear
echo -e $red" Installing xNot_Found "
sleep 1
pkg update
pkg upgrade
pkg install git
pkg install python2
pkg install lolcat
git clone https://github.com/hatakecnk/xNot_Found.git
cd xNot_Found
echo -e $red "T E R I N S T A L L "
python2 xNot_Found.py
fi

if [ $act = 12 ] || [ $act = 12 ]
then
clear
echo -e $red"Installing Lazymux"
pkg update
pkg upgrade
pkg install python2
pkg install git
git clone https://github.com/Gameye98/Lazymux 
echo -e $red"T E R I N S T A L L"
cd Lazymux
chmod +x lazymux.py
python2 lazymux.py
fi

if [ $act = 13 ] || [ $act = 13 ]
then
clear
echo -e $red"Installing Hakku"
pkg update
pkg upgrade
pkg install git
pkg install python
mkdir vasu
git clone https://github.com/4shadoww/hakkuframework
echo -e $red"T E R I N S T A L L"
fi

if [ $act = 14 ] || [ $act = 14 ]
then
clear
echo -e $red"Installing LuMrTirexV2"
pkg update
pkg upgrade
pkg install python2
pip2 install mechanize
pkg install figlet
pip2 install lolcat
pkg install git
git clone https://github.com/rikokusuma/LulMrTirexV2
cd LulMrTirexV2
echo -e $red"T E R I N S T A L L"
sh LulMrTirexV2.sh
fi

if [ $act = 15 ] || [ $act = 15 ]
then
clear
echo -e $red"Installing OSIF"
pkg update
pkg upgrade
pkg install git
pkg install python2
git clone https://github.com/ciku370/OSIF
cd OSIF
pip2 install -r requirements.txt
echo -e $red"T E R I N S T A L L"
python2 osif.py
fi

if [ $act = 16 ] || [ $act = 16 ]
then
clear
echo -e $red"Installing IP Geolocation"
pkg update
pkg upgrade
pkg install git
pkg install python
git clone https://github.com/maldevel/IPGeolocation
cd IPGeolocation
chmod +x ipgeolocation.py
pip install -r requirements.txt
echo -e $red"T E R I N S T A L L"
python ipgeolocation.py -m
fi

if [ $act = 17 ] || [ $act = 17 ]
then
clear
echo -e $red"Installing LITEDDOS"
pkg update
pkg upgrade
pkg install git
pkg install python2
git clone https://github.com/4L13199/LITEDDOS
cd LITEDDOS
echo -e $red"T E R I N S T A L L"
fi

if [ $act = 18 ] || [ $act = 18 ]
then
clear
echo -e $red"Installing B4J1N64Nv5"
pkg update
pkg upgrade
pkg install git
pkg install toilet
pkg install lolcat
pip2 install lolcat
pkg install figlet
git clone https://github.com/DarknessCyberTeam/B4J1N64Nv5
cd B4J1N64Nv5
echo -e $res"T E R I N S T A L L"
sh B4J1N64N.sh
fi

if [ $act = 19 ] || [ $act = 19 ]
then
clear
echo -e $red"Installing SQLMAP"
pkg update
pkg upgrade
pkg install git
pkg install python2
git clone https://github.com/sqlmapproject/sqlmap.git
cd sqlmap
echo -e $res"T E R I N S T A L L"
python 2 sqlmap.py
fi

if [ $act = 20 ] || [ $act = 20 ]
then
clear
echo -e $red"Installing Virus"
pkg update
pkg upgrade
pkg install git
pkg install python2
pip2 install requests
git clone https://github.com/LOoLzeC/Evil-create-framework
cd Evil-create-framework
echo -e $red"T E R I N S T A L L"
python2 vcrt.py
fi

if [ $act = 00 ] || [ $act = 00  ]
then
echo "Thank For Using My Tools "
sleep 1
echo "Thank To All Member Securty Cyber Two "
sleep 1
exit
fi

